import requests
from requests.structures import CaseInsensitiveDict
import sys,time,datetime
import pyqtgraph as pg
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtGui import *
from Sistema_monitoreo import *
from random import randrange


def request(variable):
    if variable == 1:
        url = "https://things.ubidots.com/api/v1.6/devices/raspi/humidity/lv"
    elif variable == 2:
        url = "https://things.ubidots.com/api/v1.6/devices/raspi/temperature/lv"
    else:
        url = "https://things.ubidots.com/api/v1.6/devices/raspi/position/lv"
    headers = CaseInsensitiveDict()
    headers["X-Auth-Token"] = "BBFF-iTQYLfrwC2N71WSSXDeDha1uLbXPi4"
    headers["Content-Type"] = "application/json"
    resp = requests.get(url, headers=headers)
    dataT=resp.json()
    print(dataT)
    return dataT

def timestamp():
    return int(time.mktime(datetime.datetime.now().timetuple()))

class TimeAxisItem(pg.AxisItem):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setLabel(text='Time', units=None)
        self.enableAutoSIPrefix(False)

    def tickStrings(self, values, scale, spacing):
        return [datetime.datetime.fromtimestamp(value).strftime("%d/%m-%H:%M") for value in values]

workerID=0
x=timestamp()
y=0
x_data=[x]
y_data= [0]

class Sistema_monitoreoapp(QDialog):
    def __init__(self):
        global workerID
        super().__init__()
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)

        self.scene=QGraphicsScene(self)
        pixmap=QPixmap()
        pixmap.load('Sm.jpg')
        image=pixmap.scaled(265, 165)
        item=QGraphicsPixmapItem(image)
        self.scene.addItem(item)
        self.ui.M_image.setScene(self.scene)

        self.scene2=QGraphicsScene(self)
        pixmap.load('G.jpg')
        image=pixmap.scaled(120, 100)
        item=QGraphicsPixmapItem(image)
        self.scene2.addItem(item)
        self.ui.G_image.setScene(self.scene2)

        self.scene3=QGraphicsScene(self)
        pixmap.load('T.jpg')
        image=pixmap.scaled(190, 100)
        item=QGraphicsPixmapItem(image)
        self.scene3.addItem(item)
        self.ui.T_image.setScene(self.scene3)
        
        self.scene4=QGraphicsScene(self)
        pixmap.load('H.jpg')
        image=pixmap.scaled(140, 100)
        item=QGraphicsPixmapItem(image)
        self.scene4.addItem(item)
        self.ui.H_imagge.setScene(self.scene4)

        self.ui.Clc_pB.setEnabled(False)

        self.ui.G_pB.clicked.connect(lambda:self.draw(1))
        self.ui.H_pB.clicked.connect(lambda:self.draw(2))
        self.ui.T_pB.clicked.connect(lambda:self.draw(3))
        self.ui.Clc_pB.clicked.connect(lambda:self.clear(workerID))
        

        self.show()

    def draw(self,wID):
        self.ui.G_pB.setEnabled(False)
        self.ui.H_pB.setEnabled(False)
        self.ui.T_pB.setEnabled(False)
        self.ui.Clc_pB.setEnabled(True)
        global workerID
        workerID=wID
        if workerID == 1:
            self.worker1= WorkerThread()
            self.worker1.start()
            self.worker1.update_progress.connect(self.evt_update_progress)
        elif workerID == 2:
            self.worker2= WorkerThread()
            self.worker2.start()
            self.worker2.update_progress.connect(self.evt_update_progress)
        else:
            self.worker3= WorkerThread()
            self.worker3.start()
            self.worker3.update_progress.connect(self.evt_update_progress)
        
    def evt_update_progress(self,):

        global workerID 
        if workerID == 1:
            self.ui.graphicsView.setTitle("Acelerometro",color="w", size="20px")
            self.ui.graphicsView.setLabel('left', "<span style=\"color:white;font-size:15px\">Position </span>")

        elif workerID == 2:
            self.ui.graphicsView.setTitle("Humedad",color="w", size="20px")
            self.ui.graphicsView.setLabel('left', "<span style=\"color:white;font-size:15px\">Humedad (%)</span>")
        else:
            self.ui.graphicsView.setTitle("Temperatura",color="w", size="20px")
            self.ui.graphicsView.setLabel('left', "<span style=\"color:white;font-size:15px\">Temperature (C)</span>")
        self.ui.graphicsView.setAxisItems(axisItems={'bottom': TimeAxisItem(orientation='bottom')})
        self.ui.graphicsView.setLabel('bottom', "<span style=\"color:white;font-size:15px\">Date & Time (D/M-H:M)</span>")
        self.ui.graphicsView.plot(x_data,y_data,pen=(workerID),symbol='o')

    def clearAll(self):
        global x_data,y_data,x, y
        x=0
        y=0
        x=timestamp()
        x_data=[x]
        y_data= [0]

    def clear(self,wID):
        self.ui.G_pB.setEnabled(True)
        self.ui.H_pB.setEnabled(True)
        self.ui.T_pB.setEnabled(True)
        self.clearAll()
        if wID == 1:
            self.worker1.terminate()
        elif wID == 2:
            self.worker2.terminate()
        else:
            self.worker3.terminate()  
        self.ui.graphicsView.clear() 
       
class WorkerThread(QThread):
    global workerID
    update_progress= pyqtSignal(int)
    def run(self):
        while True:
            getData(workerID)
            self.update_progress.emit(1)
            time.sleep(1)    

def getData(wID):
    global x_data,y_data,x,y
    x_data.append(timestamp())
    if wID == 1:
        y_data.append(request(wID))
    elif wID == 2:
        y_data.append(request(wID))
    else:
        y_data.append(request(wID))
    
if __name__=='__main__':
    app=QApplication(sys.argv)
    dialog=Sistema_monitoreoapp()
    dialog.show()
    sys.exit(app.exec_())